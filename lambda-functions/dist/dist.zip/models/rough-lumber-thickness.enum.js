"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RoughLumberThicknessEnum;
(function (RoughLumberThicknessEnum) {
    RoughLumberThicknessEnum["FourQtr"] = "FourQtr";
    RoughLumberThicknessEnum["FiveQtr"] = "FiveQtr";
    RoughLumberThicknessEnum["SixQtr"] = "SixQtr";
    RoughLumberThicknessEnum["EightQtr"] = "EightQtr";
    RoughLumberThicknessEnum["TwelveQtr"] = "TwelveQtr";
})(RoughLumberThicknessEnum = exports.RoughLumberThicknessEnum || (exports.RoughLumberThicknessEnum = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91Z2gtbHVtYmVyLXRoaWNrbmVzcy5lbnVtLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL21vZGVscy9yb3VnaC1sdW1iZXItdGhpY2tuZXNzLmVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFZLHdCQU1YO0FBTkQsV0FBWSx3QkFBd0I7SUFDaEMsK0NBQW1CLENBQUE7SUFDbkIsK0NBQW1CLENBQUE7SUFDbkIsNkNBQWlCLENBQUE7SUFDakIsaURBQXFCLENBQUE7SUFDckIsbURBQXVCLENBQUE7QUFDM0IsQ0FBQyxFQU5XLHdCQUF3QixHQUF4QixnQ0FBd0IsS0FBeEIsZ0NBQXdCLFFBTW5DIn0=